Deepflow
=================================
This project is command-line application that uses keras to create variational autoencoders to reduce the dimensionality of the data, until its shape can be seen on a 2D graph.
When provided with several .fcs files, this program will parse the data, analyze it using deep learning, and save a graph showing the clusterd points at the end.

To use this project, simply install the program using pip. Then, you can call the program from the command line using `deepflow`, and providing it the files to examine as arguments. 
